import React from "react";
import Home from "../Components/Home/Home";

const Emailbox = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default Emailbox;

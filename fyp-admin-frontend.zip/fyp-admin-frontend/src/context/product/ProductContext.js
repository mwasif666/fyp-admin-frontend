import { createContext } from "react";

const ProductContext = createContext();


export default ProductContext